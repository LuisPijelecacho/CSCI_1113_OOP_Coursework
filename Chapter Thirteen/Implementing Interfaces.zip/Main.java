public class Main {
    public static void main (String[] args){

        Triangle[] array = new Triangle[5];

        for(int i = 0; i < array.length; i++){
            array[i] = new Triangle((double)(Math.random() * 10),(double)(Math.random() * 10),(double)(Math.random()) * 10);
        }

        for (int i = 0; i < array.length; i++){
            System.out.println("The tringle number " + i + " has an area of " + array[i].getArea());
            array[i].howToColor();
            System.out.println("\n");
        }


    }
}
