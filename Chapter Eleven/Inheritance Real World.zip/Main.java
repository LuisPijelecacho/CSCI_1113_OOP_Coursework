import java.util.Scanner;

public class Main {
    public static void main (String[] args){

        Scanner input = new Scanner(System.in);

        System.out.println("Please enter three sides for your triangle separated by a space: ");

        Triangle triangle = new Triangle();

        triangle.setSide1(input.nextDouble());
        triangle.setSide2(input.nextDouble());
        triangle.setSide3(input.nextDouble());

        System.out.println("What is the color of your triangle? ");
        triangle.setColor(input.next());

        System.out.println("Is your triangle filled? true/false ");
        triangle.setFilled(input.nextBoolean());

        System.out.println("Your triangle was created on " + triangle.getDateCreated() + "\nThe area of your trinagle is: "
                + triangle.getArea() + "\nTHe perimeter of your tirangle is: " + triangle.getPerimeter() + "\nThe color of your triangle is: " + triangle.getColor()
                + "\nIs your triangle filled? " + triangle.isFilled());

    }
}
