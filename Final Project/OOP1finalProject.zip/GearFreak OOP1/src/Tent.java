public class Tent extends Gear{

    private int sleepingCapacity;
    private int seasons;
    private int numberOfPoles;
    private String designType;
    private String fabricMaterial;

    public Tent(){

    }
    public Tent(String brand, String name, double price, double weight, int sleepingCapacity, int seasons,
                int numberOfPoles, String designType, String fabricMaterial){
        super.setBrand(brand);
        super.setName(name);
        super. setPrice(price);
        super.setWeight(weight);
        this.sleepingCapacity = sleepingCapacity;
        this.seasons = seasons;
        this.numberOfPoles = numberOfPoles;
        this.designType = designType;
        this.fabricMaterial = fabricMaterial;
    }

    public int getSleepingCapacity() {
        return sleepingCapacity;
    }

    public void setSleepingCapacity(int sleepingCapacity) {
        this.sleepingCapacity = sleepingCapacity;
    }

    public int getSeasons() {
        return seasons;
    }

    public void setSeasons(int seasons) {
        this.seasons = seasons;
    }

    public int getNumberOfPoles() {
        return numberOfPoles;
    }

    public void setNumberOfPoles(int numberOfPoles) {
        this.numberOfPoles = numberOfPoles;
    }

    public String getDesignType() {
        return designType;
    }

    public void setDesignType(String designType) {
        this.designType = designType;
    }

    public String getFabricMaterial() {
        return fabricMaterial;
    }

    public void setFabricMaterial(String fabricMaterial) {
        this.fabricMaterial = fabricMaterial;
    }

    @Override
    public String toString() {
        return "Tent: " + getBrand() + " " + getName()
                + "\n Seasons: " + getSeasons()
                + "\n Sleeping Capacity: " + getSleepingCapacity()
                + "\n Number Of Poles: " + getNumberOfPoles()
                + "\n Fabric Material: " + getFabricMaterial()
                + "\n Design Type: " + getDesignType()
                + "\n Weight: " + getWeight()
                + "\n Price: $" + getPrice() + "\n";
    }
}
