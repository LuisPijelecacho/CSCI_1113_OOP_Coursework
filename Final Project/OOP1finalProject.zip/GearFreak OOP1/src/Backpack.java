public class Backpack extends Gear{

    private double capacityInLiters;
    private int numberOfCompartments;
    private boolean hydrationSystem;

    private String material;

    private boolean rainCoverIncluded;

    public Backpack(){

    }

    public Backpack(double capacityInLiters, int numberOfCompartments, boolean hasHydrationSystem, String brand,
                    String name, double price, double weight, String material, boolean hydrationSystem){
        super.setBrand(brand);
        super.setName(name);
        super.setPrice(price);
        super.setWeight(weight);
        this.capacityInLiters = capacityInLiters;
        this.numberOfCompartments = numberOfCompartments;
        this.material = material;
        this.hydrationSystem = hydrationSystem;
    }

    public double getCapacityInLiters() {
        return capacityInLiters;
    }

    public void setCapacityInLiters(double capacityInLiters) {
        this.capacityInLiters = capacityInLiters;
    }

    public int getNumberOfCompartments() {
        return numberOfCompartments;
    }

    public void setNumberOfCompartments(int numberOfCompartments) {
        this.numberOfCompartments = numberOfCompartments;
    }

    public boolean hasHydrationSystem() {
        return hydrationSystem;
    }

    public void setHydrationSystem(boolean hydrationSystem) {
        this.hydrationSystem = hydrationSystem;
    }


    public static String compare(Backpack o, Backpack e){
        return o.toString() + e.toString();
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public boolean hasRainCoverIncluded() {
        return rainCoverIncluded;
    }

    public void setRainCoverIncluded(boolean rainCoverIncluded) {
        this.rainCoverIncluded = rainCoverIncluded;
    }

    @Override
    public String toString() {
        return "Backpack: " + getBrand() + " " + getName()
                + "\n Capacity: " + getCapacityInLiters()
                + "\n Number of Compartments: " + getNumberOfCompartments()
                + "\n Weight: " + getWeight()
                + "\n Material: " + getMaterial()
                + "\n Rain Cover Included: " + hasRainCoverIncluded()
                + "\n Has Hydration System" + hasHydrationSystem()
                + "\n Price: $" + getPrice() + "\n";
    }
}
