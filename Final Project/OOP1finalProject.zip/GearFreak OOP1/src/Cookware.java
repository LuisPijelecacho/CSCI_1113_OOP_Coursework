public class Cookware extends Gear {

    private double liquidCapacity;
    private String cookwareMaterial;
    private boolean collapsible;

    public Cookware(){

    }
    public Cookware(String brand, String name, double price, double weight,double liquidCapacity, String cookwareMaterial,
                    boolean collapsible){
        super.setBrand(brand);
        super.setName(name);
        super. setPrice(price);
        super.setWeight(weight);
        this.liquidCapacity = liquidCapacity;
        this.cookwareMaterial = cookwareMaterial;
    }

    public double getLiquidCapacity() {
        return liquidCapacity;
    }

    public void setLiquidCapacity(double liquidCapacity) {
        this.liquidCapacity = liquidCapacity;
    }

    public String getCookwareMaterial() {
        return cookwareMaterial;
    }

    public void setCookwareMaterial(String cookwareMaterial) {
        this.cookwareMaterial = cookwareMaterial;
    }

    public boolean isCollapsible() {
        return collapsible;
    }

    public void setCollapsible(boolean collapsible) {
        this.collapsible = collapsible;
    }

    @Override
    public String toString() {
        return "Cookware: " + getBrand() + " " + getName()
                + "\n Liquid Capacity: " + getLiquidCapacity()
                + "\n Cookware Material: " + getCookwareMaterial()
                + "\n Collapsible: " + isCollapsible()
                + "\n Weight: " + getWeight()
                + "\n Price: $" + getPrice() + "\n";
    }
}
