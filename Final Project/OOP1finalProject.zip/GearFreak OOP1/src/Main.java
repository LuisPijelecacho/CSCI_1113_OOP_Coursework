import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

        addingNames();
        System.out.println("What is your name? ");
        String username = input.next();
        if(existingUser(username + ".txt")){
            System.out.println("Welcome back, " + username + "!");
            System.out.println("Here is your whole backpacking list!");
            Scanner reader = new Scanner(new FileReader("/Users/luisperez/IdeaProjects/GearFreak OOP1/users/"
                    + username + ".txt"));
            while(reader.hasNext()){
                System.out.println(reader.nextLine());
            }

        }else{
            newUserSetup(username, input);
        }

    }

    /**
     * This method adds a list of the file names into the names.txt file from the users directory
     */
    private static void addingNames(){
        File file = new File("users");
        if(!file.exists()) file.mkdir();
        File[] array = file.listFiles();
        PrintWriter output;
        try {
            output = new PrintWriter(new FileWriter("/Users/luisperez/IdeaProjects/GearFreak OOP1/users/names.txt", false));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        if (array != null) {
            for (int i = 0; i < array.length; i++){
                output.println(array[i].getName());
            }
        }
        output.close();
    }

    /**
     * This method checks if there are any usernames already in the system. If there are it returns true.
     * @param username
     *
     * @throws FileNotFoundException
     */
    private static boolean existingUser(String username) throws FileNotFoundException {
        File file = new File("/Users/luisperez/IdeaProjects/GearFreak OOP1/users/names.txt");
        Scanner reader = new Scanner(new FileReader(file));

        while(reader.hasNext()){
            String line = reader.nextLine();
            if(line.equalsIgnoreCase(username)){
                reader.close();
                return true;
            }
        }
        reader.close();
        return false;
    }

    /**
     * This method runs if the existingUser method returns false and a new user needs to be created
     * @param name
     * @param input
     */
    private static void newUserSetup(String name, Scanner input) {
        User user = new User();
        user.setName(name);
        String createList;


        System.out.println("What is your age? ");
        user.setAge(input.nextInt());

        System.out.println("What is your height? ");
        user.setHeight(input.nextDouble());

        System.out.println("What is your weight? ");
        user.setWeight(input.nextDouble());

        System.out.println("Would you like to create a gear list? ");
        createList = input.next();
        if (createList.equalsIgnoreCase("yes")) {
            Backpack[] backpackList = new Backpack[0];
            SleepingBag[] sleepingBagList = new SleepingBag[0];
            SleepingPad[] sleepingPadList = new SleepingPad[0];
            Tent[] tentList = new Tent[0];
            Stove[] stoveList = new Stove[0];
            Cookware[] cookwareList = new Cookware[0];

            String moreGear;
            
            do {
                String userInput;
                int itemCount;
                System.out.println("Name of items would you like to add? (backpack,sleeping bag, sleeping pad, tent, stove, cookware)");
                userInput = input.next();
                input.nextLine();

                switch (userInput.toLowerCase()) {
                    case "backpack":
                        System.out.println("How many backpacks would you like to add? ");
                        itemCount = input.nextInt();
                        backpackList = new Backpack[itemCount];

                        for (int i = 0; i < backpackList.length; i++) {
                            backpackList[i] = new Backpack();
                            System.out.println("Brand: ");
                            input.nextLine();
                            backpackList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            backpackList[i].setName(input.nextLine());
                            System.out.println("Capacity in Liters: ");
                            backpackList[i].setCapacityInLiters(input.nextDouble());
                            System.out.println("Weight: ");
                            backpackList[i].setWeight(input.nextDouble());
                            System.out.println("Material: ");
                            input.nextLine();
                            backpackList[i].setMaterial(input.nextLine());
                            System.out.println("Is a rain cover included? (true/false)");
                            backpackList[i].setRainCoverIncluded(input.nextBoolean());
                            System.out.println("Does it have a hydration system? (true/false)");
                            backpackList[i].setHydrationSystem(input.nextBoolean());
                            System.out.println("What was the price on your pack? ");
                            backpackList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Pack number " + i);
                            }
                        }
                        break;

                    case "sleeping bag":
                        System.out.println("How many sleeping bags would you like to add? ");
                        itemCount = input.nextInt();
                        sleepingBagList = new SleepingBag[itemCount];

                        for (int i = 0; i < sleepingBagList.length; i++) {
                            sleepingBagList[i] = new SleepingBag();
                            System.out.println("Brand: ");
                            input.nextLine();
                            sleepingBagList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            sleepingBagList[i].setName(input.nextLine());
                            System.out.println("Temperature Rating: ");
                            sleepingBagList[i].setTemperatureRating(input.nextDouble());
                            System.out.println("Insulation Type: ");
                            input.nextLine();
                            sleepingBagList[i].setInsulationType(input.nextLine());
                            System.out.println("Shell Material: ");
                            sleepingBagList[i].setShell(input.nextLine());
                            System.out.println("Is it water-resistant? (true/false)");
                            sleepingBagList[i].setWaterResistant(input.nextBoolean());
                            System.out.println("Weight: ");
                            sleepingBagList[i].setWeight(input.nextDouble());
                            System.out.println("What was the price on your sleeping bag? ");
                            sleepingBagList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Sleeping bag number " + i);
                            }
                        }
                        break;

                    case "sleeping pad":
                        System.out.println("How many sleeping pads would you like to add? ");
                        itemCount = input.nextInt();
                        sleepingPadList = new SleepingPad[itemCount];

                        for (int i = 0; i < sleepingPadList.length; i++) {
                            sleepingPadList[i] = new SleepingPad();
                            System.out.println("Brand: ");
                            input.nextLine();
                            sleepingPadList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            sleepingPadList[i].setName(input.nextLine());
                            System.out.println("Is it insulated? ");
                            sleepingPadList[i].setInsulated(input.nextBoolean());
                            System.out.println("Insulation Type: ");
                            input.nextLine();
                            sleepingPadList[i].setInsulationType(input.nextLine());
                            System.out.println("What is the R-Value: ");
                            sleepingPadList[i].setRValue(input.nextDouble());
                            System.out.println("What type of sleeping pad is it? (inflatable, foam, etc.)");
                            input.nextLine();
                            sleepingPadList[i].setSleepingPadType(input.nextLine());
                            System.out.println("Weight: ");
                            sleepingPadList[i].setWeight(input.nextDouble());
                            System.out.println("What was the price on your sleeping pad? ");
                            sleepingPadList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Sleeping pad number " + i);
                            }
                        }
                        break;

                    case "tent":
                        System.out.println("How many tents would you like to add? ");
                        itemCount = input.nextInt();
                        tentList = new Tent[itemCount];

                        for (int i = 0; i < tentList.length; i++) {
                            tentList[i] = new Tent();
                            System.out.println("Brand: ");
                            input.nextLine();
                            tentList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            tentList[i].setName(input.nextLine());
                            System.out.println("How many seasons is the tent for? ");
                            tentList[i].setSeasons(input.nextInt());
                            System.out.println("What is the sleeping capacity? ");
                            tentList[i].setSleepingCapacity(input.nextInt());
                            System.out.println("What is the number of poles? ");
                            tentList[i].setNumberOfPoles(input.nextInt());
                            System.out.println("Material: ");
                            input.nextLine();
                            tentList[i].setFabricMaterial(input.nextLine());
                            System.out.println("What is the tent design? (freestanding, non-freestanding, trekking pole)");
                            input.nextLine();
                            tentList[i].setDesignType(input.nextLine());
                            System.out.println("Weight: ");
                            tentList[i].setWeight(input.nextDouble());
                            System.out.println("What was the price on your tent? ");
                            tentList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Tent number " + i);
                            }
                        }
                        break;

                    case "stove":
                        System.out.println("How many stoves would you like to add? ");
                        itemCount = input.nextInt();
                        stoveList = new Stove[itemCount];

                        for (int i = 0; i < stoveList.length; i++) {
                            stoveList[i] = new Stove();
                            System.out.println("Brand: ");
                            input.nextLine();
                            stoveList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            stoveList[i].setName(input.nextLine());
                            System.out.println("Fuel type (Canister, Pressure Bottle, Wood, Tablet):  ");
                            stoveList[i].setFuelType(input.nextLine());
                            input.nextLine();
                            System.out.println("Fuel: ");
                            input.nextLine();
                            stoveList[i].setFuel(input.nextLine());
                            System.out.println("Number of burners: ");
                            stoveList[i].setNumberOfBurners(input.nextInt());
                            System.out.println("Does it have auto-ignition? (true/false): ");
                            stoveList[i].setAutoIgnition(input.nextBoolean());
                            System.out.println("Weight: ");
                            stoveList[i].setWeight(input.nextDouble());
                            System.out.println("What was the price on your stove? ");
                            stoveList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Stove number " + i);
                            }
                        }
                        break;

                    case "cookware":
                        System.out.println("How many cookware items would you like to add? ");
                        itemCount = input.nextInt();
                        cookwareList = new Cookware[itemCount];

                        for (int i = 0; i < cookwareList.length; i++) {
                            cookwareList[i] = new Cookware();
                            System.out.println("Brand: ");
                            input.nextLine();
                            cookwareList[i].setBrand(input.nextLine());
                            System.out.println("Name: ");
                            cookwareList[i].setName(input.nextLine());
                            System.out.println("Liquid Capacity:");
                            cookwareList[i].setLiquidCapacity(input.nextDouble());
                            System.out.println("Cookware Material: ");
                            input.nextLine();
                            cookwareList[i].setCookwareMaterial(input.nextLine());
                            System.out.println("Is it collapsible? ");
                            cookwareList[i].setCollapsible(input.nextBoolean());
                            System.out.println("Weight: ");
                            cookwareList[i].setWeight(input.nextDouble());
                            System.out.println("What was the price on your cookware? ");
                            cookwareList[i].setPrice(input.nextDouble());

                            if (itemCount > 1) {
                                System.out.println("Cookware number " + i);
                            }
                        }
                        break;
                }
                input.nextLine();

                System.out.println("Would you like to add any other gear? (backpack, sleeping bag, sleeping pad, tent, stove, cookware)");
                moreGear = input.nextLine();

            } while (!moreGear.equalsIgnoreCase("no"));


            File file = new File("users/" + user.name.toLowerCase() + ".txt");

            try (
                    PrintWriter output = new PrintWriter(new FileWriter(file, true))
            ) {

                for (Backpack backpack : backpackList) {
                    output.println(backpack.toString());
                }

                for (SleepingBag sleepingBag : sleepingBagList) {
                    output.println(sleepingBag.toString());
                }

                for (SleepingPad sleepingPad : sleepingPadList) {
                    output.println(sleepingPad.toString());
                }

                for (Tent tent : tentList) {
                    output.println(tent.toString());
                }

                for (Stove stove : stoveList) {
                    output.println(stove.toString());
                }

                for (Cookware cookware : cookwareList) {
                    output.println(cookware.toString());
                }


            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }
}