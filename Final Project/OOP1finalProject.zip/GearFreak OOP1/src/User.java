import java.util.ArrayList;
import java.util.List;

public class User {

    String name;
    int age;
    double weight;
    double height;
    String gender;
    String email;
     List<Gear> gearList;


    public User(){

    }

    public User(String name, int age, double weight, double height){
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.gearList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void addGear(Gear gear){
        gearList.add(gear);
    }

    public void removeGear(Gear gear){
        gearList.remove(gear);
    }
    public void printGear(){
        gearList.toString();
    }

    public void setGearList(ArrayList<Gear>list){
        ArrayList<Gear> gearList = new ArrayList<>();
    }

}
