public class Stove extends Gear{

    private String fuelType;
    private String fuel;
    private boolean autoIgnition;
    private int numberOfBurners;

    public Stove(){

    }

    public Stove(String brand, String name, double price, double weight, String fuelType, String fuel, boolean autoIgnition,
                 int numberOfBurners){
        super.setBrand(brand);
        super.setName(name);
        super. setPrice(price);
        super.setWeight(weight);
        this.fuelType = fuelType;
        this.fuel = fuel;
        this.autoIgnition = autoIgnition;
        this.numberOfBurners = numberOfBurners;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public boolean hasAutoIgnition() {
        return autoIgnition;
    }

    public void setAutoIgnition(boolean autoIgnition) {
        this.autoIgnition = autoIgnition;
    }

    public int getNumberOfBurners() {
        return numberOfBurners;
    }

    public void setNumberOfBurners(int numberOfBurners) {
        this.numberOfBurners = numberOfBurners;
    }

    @Override
    public String toString() {
        return "Stove: " + getBrand() + " " + getName()
                + "\n Fuel Type: " + getFuelType()
                + "\n Fuel: " + getFuel()
                + "\n Number Of Burners: " + getNumberOfBurners()
                + "\n Auto Ignition: " + hasAutoIgnition()
                + "\n Weight: " + getWeight()
                + "\n Price: $" + getPrice() + "\n";
    }
}
