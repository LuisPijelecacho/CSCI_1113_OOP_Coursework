public class SleepingBag extends Gear{

    private double temperatureRating;
    private String shell;
    private String insulationType;
    private boolean waterResistant;


    public SleepingBag(){

    }

    public SleepingBag(String brand, String name, double price, double weight, double temperatureRating,String shell,
                       String insulationType, boolean waterResistant){
        super.setBrand(brand);
        super.setName(name);
        super. setPrice(price);
        super.setWeight(weight);
        this.temperatureRating = temperatureRating;
        this.shell = shell;
        this.insulationType = insulationType;
    }

    public double getTemperatureRating() {
        return temperatureRating;
    }

    public void setTemperatureRating(double temperatureRating) {
        this.temperatureRating = temperatureRating;
    }

    public String getShell() {
        return shell;
    }

    public void setShell(String shell) {
        this.shell = shell;
    }

    public String getInsulationType() {
        return insulationType;
    }

    public void setInsulationType(String insulationType) {
        this.insulationType = insulationType;
    }

    public boolean isWaterResistant() {
        return waterResistant;
    }

    public void setWaterResistant(boolean waterResistant) {
        this.waterResistant = waterResistant;
    }

    @Override
    public String toString() {
        return "Sleeping Bag: " + getBrand() + " " + getName()
                + "\n Temperature Rating: " + getTemperatureRating()
                + "\n Insulation Type: " + getInsulationType()
                + "\n Shell Material: " + getShell()
                + "\n Waterproof: " + isWaterResistant()
                + "\n Weight: " + getWeight()
                + "\n Price: $" + getPrice() + "\n";
    }
}
