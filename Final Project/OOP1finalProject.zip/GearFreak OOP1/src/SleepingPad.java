public class SleepingPad extends Gear{

    private String sleepingPadType;
    private double rValue;
    private boolean insulated;
    private String insulationType;


    public SleepingPad(){

    }
    public SleepingPad(String brand, String name, double price, double weight, String sleepingPadType, double rValue,
                       boolean insulated, String insulationType){
        super.setBrand(brand);
        super.setName(name);
        super. setPrice(price);
        super.setWeight(weight);
        this.sleepingPadType = sleepingPadType;
        this.rValue = rValue;
        this.insulated = insulated;
        this.insulationType = insulationType;
    }

    public String getSleepingPadType() {
        return sleepingPadType;
    }

    public void setSleepingPadType(String sleepingPadType) {
        this.sleepingPadType = sleepingPadType;
    }

    public double getRValue() {
        return rValue;
    }

    public void setRValue(double rValue) {
        this.rValue = rValue;
    }

    public boolean isInsulated() {
        return insulated;
    }

    public void setInsulated(boolean insulated) {
        this.insulated = insulated;
    }

    public String getInsulationType() {
        return insulationType;
    }

    public void setInsulationType(String insulationType) {
        this.insulationType = insulationType;
    }

    @Override
    public String toString() {
        return "Sleeping Pad: " + getBrand() + " " + getName()
                + "\n Is Insulated: " + isInsulated()
                + "\n Insulation Type: " + getInsulationType()
                + "\n R - Value: " + getRValue()
                + "\n Sleeping Pad Type: " + getSleepingPadType()
                + "\n Weight: " + getWeight()
                + "\n Price: $" + getPrice() + "\n";
    }
}
