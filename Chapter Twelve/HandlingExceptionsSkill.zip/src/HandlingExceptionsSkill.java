import java.util.Scanner;

public class HandlingExceptionsSkill {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        int index = 0;
        int[] array = new int[100];

        for (int i = 0; i < 100; i++) {
            array[i] = (int) (Math.random() * 10);
        }
        System.out.println("Choose an index position to display its number: ");
        try {
            index = input.nextInt();
            System.out.println("The requested index #" + index + " holds the value " + array[index]);
        } catch (ArrayIndexOutOfBoundsException aIOOBE) {
            while (index > 100 || index < 0) {
                System.out.println("Your array index is out of bounds, " +
                        "please keep your array index between 1 and 100 " + "\n Try again: ");
                index = input.nextInt();
            }
            System.out.println("The requested index #" + index + " holds the value " + array[index]);
        }


    }
}
