import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main (String[] args){
        File file = new File("Exercise12_15.txt");
        ArrayList<Integer> list = new ArrayList<>();

        try {
            FileWriter fileWriter = new FileWriter(file, false);
            for (int i = 0; i < 100; i++) {
                fileWriter.write(((int) ((Math.random() * 1000) + 1)) + " ");
            }
            fileWriter.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }

        try {
            Scanner input = new Scanner(file);
            while (input.hasNext()) {
                list.add(input.nextInt());
            }
        } catch (FileNotFoundException e) {
           System.out.println("The file you are trying to read from does not exist!");
        }
        Collections.sort(list);
        System.out.println(list);


    }
}
